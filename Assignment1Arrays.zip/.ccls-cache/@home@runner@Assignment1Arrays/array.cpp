using namespace std;
#include <iostream>
#include "array.h"

// tasks: integer exists
// modify value of integer based on index
// adds new integer to end of array
// takes index and removes from array

void readArray(int userArr[]){
  cout << "Current Array";
  for (int i = 0; i < 10; i++){
    cout << userArr[i] << " , ";
  }
}

int whereInt(int userArr){
}

int modifyArr(int userArr, int userIndex){ 
}

int addNum(int userArr, int choice){
}

int removeNum(int userArr, int userIndex){
}