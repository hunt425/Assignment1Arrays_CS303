#include <iostream>

class ArrayClass{
  void readArray(int userArr[]){
  }
  
  int whereInt(int userArr){
  }
  
  int modifyArr(int userArr, int userIndex){ 
  }
  
  int addNum(int userArr, int choice){
  }
  
  int removeNum(int userArr, int userIndex){
  }
};